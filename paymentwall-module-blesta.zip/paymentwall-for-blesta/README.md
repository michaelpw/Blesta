#About Blesta module
Paymentwall module for Blesta.


###Versions
* Tested on Blesta 3.5.2
* PHP 5.3 or later

#Installation
To install Paymentwall Blesta module, please follow the [instructions](https://www.paymentwall.com/en/documentation/Blesta/3439).

After cloning the repository don't forget to install Paymentwall PHP API library (**required**):
`git submodule init` and then `git submodule update`
